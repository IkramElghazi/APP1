<?php
try {
    $dbh = new PDO('mysql:host=localhost;dbname=gestion_ecole', $user = "root", $pass = "");

} catch (PDOException $e) {
    print "Error!: " . $e->getMessage() . "<br/>";
    die();
}
?>  