<?php
require_once("includes/header.php");





require_once("includes/nav.php");
require_once("home.php");





require_once("includes/footer.php");


